package com.tempProjectBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TempProjectBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
